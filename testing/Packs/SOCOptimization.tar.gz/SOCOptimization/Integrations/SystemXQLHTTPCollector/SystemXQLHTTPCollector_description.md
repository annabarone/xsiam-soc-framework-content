Used to post data to an XSIAM data set. This does not require an Custom - HTTP Collector Data Source Integration to use,
but it must be uploaded via the demisto-sdk upload --zip --xsiam command to register as a SYSTEM level integration.

Correlation rule can then be created to generate alerts based on the data generated from this command.